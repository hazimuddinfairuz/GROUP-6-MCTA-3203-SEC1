#include <WiFi.h>
#include <esp_now.h>
#include <Wire.h>
#include "HUSKYLENS.h"
#include "BluetoothSerial.h" // <--- NEW LIBRARY

// ================= CONFIG =================
uint8_t receiverMAC[] = {0xE8, 0x31, 0xCD, 0x4D, 0xE5, 0xD8}; // Wallet MAC
const int buttonPin = 25;
const int vibrationMotorPin = 17;

// ================= OBJECTS =================
HUSKYLENS huskylens;
BluetoothSerial SerialBT; // <--- Create Bluetooth Object

// ================= VARIABLES =================
bool buttonActive = false;
bool lastButtonState = HIGH;
unsigned long lastDebounce = 0;

bool huskyActive = false;
bool huskyConnected = false;

// ================= DATA STRUCT =================
typedef struct message {
  char command[20];
} message;

message dataToSend;

// ================= ESP-NOW CALLBACK =================
void OnDataSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  // Optional: You can debug here, but we focus on Bluetooth for Pi
}

// ================= SEND FUNCTION =================
void sendCommand(const char* cmd) {
  // 1. Send to Wallet (Fast ESP-NOW)
  strcpy(dataToSend.command, cmd);
  esp_now_send(receiverMAC, (uint8_t *)&dataToSend, sizeof(dataToSend));
  
  // 2. Send to Pi (Bluetooth)
  // We send it as text with a "newline" so Pi can read it easily
  if (SerialBT.hasClient()) {
     SerialBT.println(cmd); 
  }
  
  Serial.print("Sent Global Command: ");
  Serial.println(cmd);
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(vibrationMotorPin, OUTPUT);
  digitalWrite(vibrationMotorPin, LOW);
  Wire.begin(21, 22);

  // --- 1. SETUP WIFI (ESP-NOW) ---
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
  esp_now_register_send_cb(OnDataSent);

  // Register Wallet Peer
  esp_now_peer_info_t peerInfo = {};
  memcpy(peerInfo.peer_addr, receiverMAC, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  esp_now_add_peer(&peerInfo);

  // --- 2. SETUP BLUETOOTH (For Pi 5) ---
  // The name "SmartBracelet" will show up on your Pi
  SerialBT.begin("SmartBracelet"); 
  Serial.println("Bluetooth Started! Pair your Pi with 'SmartBracelet'");

  // --- 3. SETUP HUSKYLENS ---
  if (!huskylens.begin(Wire)) {
    delay(500);
    huskylens.begin(Wire);
  }
  if (huskylens.request()) {
    huskyConnected = true;
    Serial.println("HuskyLens Connected");
  }
}

// ================= LOOP =================
void loop() {
  // -------- BUTTON --------
  int reading = digitalRead(buttonPin);
  
  if (reading == LOW && lastButtonState == HIGH && millis() - lastDebounce > 200) {
    buttonActive = !buttonActive;
    lastDebounce = millis();
    if (buttonActive) sendCommand("BUTTON_ON");
    else sendCommand("BUTTON_OFF");
  }
  lastButtonState = reading;

  // -------- HUSKYLENS --------
  bool currentDetect = false;
  if (huskyConnected && huskylens.request()) {
    // Only verify ID 1 (The Tag)
    if (huskylens.available()) {
       HUSKYLENSResult result = huskylens.read();
       if (result.ID == 1) currentDetect = true;
    }
  }

  if (currentDetect != huskyActive) {
    huskyActive = currentDetect;
    if (huskyActive) {
      digitalWrite(vibrationMotorPin, HIGH);
      sendCommand("HUSKY_ON");
    } else {
      digitalWrite(vibrationMotorPin, LOW);
      sendCommand("HUSKY_OFF");
    }
  }
  delay(50);
}