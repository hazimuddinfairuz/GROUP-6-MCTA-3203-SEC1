#include <WiFi.h>
#include <esp_now.h>

const int buzzerPin = 5;

bool buttonRequest = false;

typedef struct message {
  char command[20];
} message;

message incomingData;

// ================= UPDATE OUTPUTS =================
void updateOutputs() {
  digitalWrite(buzzerPin, buttonRequest ? HIGH : LOW);
  
  Serial.print("Buzzer: "); 
  Serial.println(buttonRequest ? "ON" : "OFF");
}

// ================= RECEIVE CALLBACK =================
void onReceive(const esp_now_recv_info_t * info, const uint8_t *incomingDataBytes, int len) {
  memcpy(&incomingData, incomingDataBytes, sizeof(incomingData));
  String cmd = String(incomingData.command);

  Serial.print("Message received: ");
  Serial.println(cmd);

  if (cmd == "BUTTON_ON") {
    buttonRequest = true;
  } 
  else if (cmd == "BUTTON_OFF") {
    buttonRequest = false;
  }

  updateOutputs();
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  
  pinMode(buzzerPin, OUTPUT);
  digitalWrite(buzzerPin, LOW);

  WiFi.mode(WIFI_STA);
  
  // Print MAC Address
  uint64_t chipid = ESP.getEfuseMac();
  Serial.printf(
    "RECEIVER MAC Address: %02X:%02X:%02X:%02X:%02X:%02X\n",
    (uint8_t)(chipid >> 40),
    (uint8_t)(chipid >> 32),
    (uint8_t)(chipid >> 24),
    (uint8_t)(chipid >> 16),
    (uint8_t)(chipid >> 8),
    (uint8_t)(chipid)
  );

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW Init Failed");
    return;
  }

  esp_now_register_recv_cb(onReceive);

  Serial.println("Receiver Ready. Waiting for button commands...");
}

void loop() {
  delay(100);
}